"""
Python 'wcwidth' module.

https://github.com/jquast/wcwidth
"""

# re-export common and outermost functions & definitions, even a few private
# ones, some for convenience, others for legacy, only the items in __all__ are
# documented as public API

__lazy_modules__ = [
    "wcwidth._clip",
    "wcwidth._wcswidth",
    "wcwidth._wcwidth",
    "wcwidth._width",
    "wcwidth.align",
    "wcwidth.bisearch",
    "wcwidth.escape_sequences",
    "wcwidth.grapheme",
    "wcwidth.hyperlink",
    "wcwidth.sgr_state",
    "wcwidth.table_ambiguous",
    "wcwidth.table_vs16",
    "wcwidth.table_wide",
    "wcwidth.table_zero",
    "wcwidth.text_sizing",
    "wcwidth.textwrap",
    "wcwidth.unicode_versions",
]

# local
from ._clip import clip
from .align import ljust, rjust, center
from ._width import width
from .bisearch import bisearch as _bisearch
from .grapheme import iter_graphemes, iter_graphemes_reverse, grapheme_boundary_before
from .textwrap import SequenceTextWrapper, wrap
from ._wcswidth import wcswidth, wcstwidth
from .hyperlink import Hyperlink, HyperlinkParams
from .sgr_state import propagate_sgr
from ._constants import list_term_programs
from .table_vs16 import VS16_NARROW_TO_WIDE
from .table_wide import WIDE_EASTASIAN
from .table_zero import ZERO_WIDTH
from .text_sizing import TextSizing, TextSizingParams
from .table_ambiguous import AMBIGUOUS_EASTASIAN
from .escape_sequences import iter_sequences, strip_sequences
from .unicode_versions import list_versions

# Import order matters for legacy API compatibility (releases before 0.7.0).
#
# The first release put every function in a single 'wcwidth.py' file, and while the top-level
# 'from wcwidth import wcswidth' was always preferred, the deeper
# 'from wcwidth.wcwidth import wcswidth' form was always possible too.  Both keep working.
#
# Below 3.15 the legacy submodule is pre-imported so sys.modules['wcwidth.wcwidth'] is populated
# during package initialization; a later ``import wcwidth.wcwidth`` would otherwise trigger on-disk
# file discovery and rebind that name from the function to the module object.  On 3.15+
# __lazy_modules__ covers every submodule and the shim loads on demand.
if __import__('sys').version_info < (3, 15):
    from . import wcwidth as _wcwidth_module  # isort:skip
from ._wcwidth import wcwidth, _wcmatch_version, _wcversion_value  # isort:skip  # pylint: disable=wrong-import-position


# The __all__ attribute defines the items exported from statement,
# 'from wcwidth import *', but also to say, "This is the public API".
__all__ = ('wcwidth', 'wcswidth', 'wcstwidth', 'width', 'iter_sequences', 'iter_graphemes',
           'iter_graphemes_reverse', 'grapheme_boundary_before',
           'ljust', 'rjust', 'center', 'wrap', 'clip', 'strip_sequences',
           'list_versions', 'list_term_programs', 'propagate_sgr',
           'Hyperlink', 'HyperlinkParams', 'TextSizing', 'TextSizingParams')

# Version is stamped by code generation (bin/update-tables.py) from pyproject.toml.
__version__ = '0.8.5'
